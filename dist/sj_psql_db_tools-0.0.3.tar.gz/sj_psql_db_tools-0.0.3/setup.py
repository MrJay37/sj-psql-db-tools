from setuptools import setup

setup(
    name='sj-psql-db-tools',
    version='0.0.3',
    description='PostgresQL database tools for my projects',
    install_requires=[
        'pg8000',
    ],
)